
<!DOCTYPE html>
<html>
<head>
	<title>Public Home Page</title>
</head>
<body>

	<?php require'Welcome.php'?>
	
	<h1>Welcome to Alumni Management System</h1>
	
	<?php  require'footer.php' ?>
	

</body>
</html>
