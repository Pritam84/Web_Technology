<!DOCTYPE html>
<html>
<head>
	<title>Header</title>
</head>
<body>
	<?php?>
	<p style="font-size: 30px; background-color: #AED6F1 " align="right" >
    <a href="Registration.php">Registration &nbsp<b>|</b></a>
	<a href="Login.php" align="right">Login &nbsp<b>|</b></a>
	<a href="Home.php" align="right">Home </a> </p>

</body>
</html>